import flet as ft

def main(page: ft.Page):
    page.title = "Simple program"
    chats_list = ft.Column()
    field = ft.TextField(label="What need to be done !!!")
    def message(e):
        if field.value != "":
            chats_list.controls.append(ft.Text(field.value))
            field.value = ""
            page.update()
        else:
            field.error_text = "Please enter something to be done"
            field.update()
    def clear(e):
        chats_list.clean()
        page.update()
        chats_list.update()
    page.add(
        ft.Row(controls=[
        field,
        ft.FloatingActionButton(ft.icons.ADD, on_click=message), ft.FloatingActionButton(ft.icons.CLEAR, on_click=clear)]),
        chats_list,

    )
ft.app(main)